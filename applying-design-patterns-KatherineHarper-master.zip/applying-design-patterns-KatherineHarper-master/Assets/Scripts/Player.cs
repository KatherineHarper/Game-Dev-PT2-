﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

    public GameObject CubePickup;
    public int pickupsGathered;
    public int lastXpos;
    public int lastYpos;
    public int newXpos;
    public int newYpos;

    // Use this for initialization
    void Start () {
        lastXpos = 0;
        lastYpos = 0;
        newXpos = 0;
        newYpos = 0;
        pickupsGathered = 0;
    }

    void FixedUpdate()
    {
        if (Time.frameCount % 5 == 0) // create new pickup every 2nd update
            CreatePickup();
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Pickup"))
        {
            Destroy(other.gameObject);
            pickupsGathered++;
        }
    }

    private void CreatePickup()
    {
      
        GameObject newPickup = (GameObject)GameObject.Instantiate(CubePickup);
       
        newYpos = lastYpos + 1;
        newPickup.transform.position = new Vector3(newXpos, newYpos);

        lastXpos = newXpos;
        lastYpos = newYpos;


    }
}

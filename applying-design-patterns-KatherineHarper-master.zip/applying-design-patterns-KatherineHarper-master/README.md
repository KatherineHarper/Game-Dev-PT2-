# DesignPatternsPractice
Activity on using Singleton and Object Pool design patterns
